﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collectiblesScript : MonoBehaviour
{
   private float speed = 3f;
   public void OnTriggerEnter(Collider other)
    {
        other.GetComponentInParent<playerMovment>().number += 50; //change scores first
        Destroy(gameObject);
    }

    void Update()
    {
        transform.Rotate(0,speed, 0);
    }
}
