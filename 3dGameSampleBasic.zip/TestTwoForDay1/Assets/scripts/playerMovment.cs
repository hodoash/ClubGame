﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerMovment : MonoBehaviour
{
    public int number;
    public Text score;

    public float speed = 50f;
    private float moveHorizontal, moveVertical;
    Rigidbody myBody;
    // Start is called before the first frame update
    void Start()
    {
        myBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        moveHorizontal = Input.GetAxis("Horizontal");
        moveVertical = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(moveHorizontal, 0f, moveVertical);
        myBody.AddForce(move*speed);

        score.text = "Player Score : " + number.ToString();
        
    }
}
